"""A simple package for testing sphinx_pyscript."""

__version__ = "0.1.0"
